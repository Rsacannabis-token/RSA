package core

import (
	"time"
)

const (
	HeartbeatInterval = 12 * time.Second
)
