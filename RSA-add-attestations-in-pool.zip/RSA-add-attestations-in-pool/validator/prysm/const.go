package prysm

import (
	"time"
)

const (
	PollingInterval = 6 * time.Second
)
