package metrics

import (
	"time"
)

const PollingInterval = 30 * time.Second
